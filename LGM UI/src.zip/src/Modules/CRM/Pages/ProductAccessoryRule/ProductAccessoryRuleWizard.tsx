import React, { useEffect, useState } from "react";
import type { ProductAccessoryRule } from "./Services/types";
import { saveProductAccessoryRule } from "./Services/ProductAccessoryRuleService";
import { toast } from "sonner";
import { buttonStyles } from "../../../../Components/Common/buttonStyles";

interface WizardProps { editData: ProductAccessoryRule | null; onSuccess: () => void; onCancel: () => void; }
const emptyRule: ProductAccessoryRule = { id: 0, productId: 0, accessoriesId: 0, quantity: 1, mandatoryOptional: "Optional", pricingType: "Default", defaultPrice: 0, effectiveFrom: new Date().toISOString().slice(0, 10), effectiveTo: null, active: true, isDeleted: false };
const dateValue = (value?: string | null) => value ? value.slice(0, 10) : "";
const ProductAccessoryRuleWizard: React.FC<WizardProps> = ({ editData, onSuccess, onCancel }) => {
  const [data, setData] = useState<ProductAccessoryRule>({ ...emptyRule });
  const [isSaving, setIsSaving] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  useEffect(() => { setData(editData ? { ...emptyRule, ...editData, effectiveFrom: dateValue(editData.effectiveFrom), effectiveTo: dateValue(editData.effectiveTo) || null } : { ...emptyRule }); setErrors({}); }, [editData]);
  const update = (field: keyof ProductAccessoryRule, value: string | number | boolean | null) => { setData((old) => ({ ...old, [field]: value })); setErrors((old) => ({ ...old, [field]: "" })); };
  const validate = () => {
    const next: Record<string, string> = {};
    if (!Number.isInteger(Number(data.productId)) || Number(data.productId) <= 0) next.productId = "Enter a valid Product ID.";
    if (!Number.isInteger(Number(data.accessoriesId)) || Number(data.accessoriesId) <= 0) next.accessoriesId = "Enter a valid Accessory ID.";
    if (!Number.isInteger(Number(data.quantity)) || Number(data.quantity) < 1) next.quantity = "Quantity must be at least 1.";
    if (!data.mandatoryOptional.trim()) next.mandatoryOptional = "Choose Mandatory or Optional.";
    if (data.mandatoryOptional.length > 20) next.mandatoryOptional = "Must be 20 characters or fewer.";
    if (!data.pricingType.trim()) next.pricingType = "Pricing Type is required.";
    if (data.pricingType.length > 30) next.pricingType = "Pricing Type must be 30 characters or fewer.";
    if (!Number.isFinite(Number(data.defaultPrice)) || Number(data.defaultPrice) < 0) next.defaultPrice = "Default Price cannot be negative.";
    if (data.effectiveTo && data.effectiveFrom && data.effectiveTo < data.effectiveFrom) next.effectiveTo = "Effective To must be on or after Effective From.";
    setErrors(next); return Object.keys(next).length === 0;
  };
  const handleSave = async () => {
    if (!validate()) { toast.error("Please correct the highlighted fields."); return; }
    setIsSaving(true);
    try { await saveProductAccessoryRule({ ...data, quantity: Number(data.quantity), defaultPrice: Number(data.defaultPrice), effectiveFrom: data.effectiveFrom ? `${dateValue(data.effectiveFrom)}T00:00:00` : "", effectiveTo: data.effectiveTo ? `${dateValue(data.effectiveTo)}T00:00:00` : null }); toast.success(data.id > 0 ? "Product accessory rule updated successfully!" : "Product accessory rule created successfully!"); onSuccess(); }
    catch (error: unknown) { toast.error(error instanceof Error ? error.message : "Something went wrong while saving this rule."); }
    finally { setIsSaving(false); }
  };
  const inputClass = "w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm outline-none transition focus:border-[#f07837] focus:ring-2 focus:ring-[#f07837]/20";
  const labelClass = "mb-1 block text-xs font-bold uppercase tracking-wide text-gray-600";
  const errorText = (key: string) => errors[key] ? <p className="mt-1 text-xs text-red-600">{errors[key]}</p> : null;
  return <div className="mb-8 overflow-hidden rounded-xl border border-gray-200 bg-white shadow-xl">
    <header className="bg-[#f07837] px-6 py-4 text-white"><h2 className="text-lg font-bold uppercase tracking-wide">{data.id ? "Update Product Accessory Rule" : "Add Product Accessory Rule"}</h2><p className="mt-1 text-xs text-white/80">Configure the accessory requirement and pricing.</p></header>
    <div className="p-5 sm:p-8"><h3 className="mb-5 border-b border-gray-200 pb-3 text-sm font-extrabold uppercase tracking-wide text-[#154068]">Rule Information</h3>
      <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
        <div><label htmlFor="productId" className={labelClass}>Product ID *</label><input id="productId" type="number" min="1" step="1" value={data.productId || ""} onChange={(e) => update("productId", e.target.value === "" ? 0 : Number(e.target.value))} className={inputClass} placeholder="Enter Product ID" />{errorText("productId")}</div>
        <div><label htmlFor="accessoriesId" className={labelClass}>Accessories ID *</label><input id="accessoriesId" type="number" min="1" step="1" value={data.accessoriesId || ""} onChange={(e) => update("accessoriesId", e.target.value === "" ? 0 : Number(e.target.value))} className={inputClass} placeholder="Enter Accessories ID" />{errorText("accessoriesId")}</div>
        <div><label htmlFor="quantity" className={labelClass}>Quantity *</label><input id="quantity" type="number" min="1" step="1" value={data.quantity} onChange={(e) => update("quantity", e.target.value === "" ? 0 : Number(e.target.value))} className={inputClass} />{errorText("quantity")}</div>
        <div><label htmlFor="mandatoryOptional" className={labelClass}>Requirement *</label><select id="mandatoryOptional" value={data.mandatoryOptional} onChange={(e) => update("mandatoryOptional", e.target.value)} className={inputClass}><option value="Mandatory">Mandatory</option><option value="Optional">Optional</option></select>{errorText("mandatoryOptional")}</div>
        <div><label htmlFor="pricingType" className={labelClass}>Pricing Type *</label><input id="pricingType" maxLength={30} value={data.pricingType} onChange={(e) => update("pricingType", e.target.value)} className={inputClass} placeholder="e.g. Default, Fixed" />{errorText("pricingType")}</div>
        <div><label htmlFor="defaultPrice" className={labelClass}>Default Price</label><input id="defaultPrice" type="number" min="0" step="0.01" value={data.defaultPrice} onChange={(e) => update("defaultPrice", e.target.value === "" ? 0 : Number(e.target.value))} className={inputClass} placeholder="0.00" />{errorText("defaultPrice")}</div>
        <div><label htmlFor="effectiveFrom" className={labelClass}>Effective From</label><input id="effectiveFrom" type="date" value={dateValue(data.effectiveFrom)} onChange={(e) => update("effectiveFrom", e.target.value)} className={inputClass} /></div>
        <div><label htmlFor="effectiveTo" className={labelClass}>Effective To</label><input id="effectiveTo" type="date" value={dateValue(data.effectiveTo)} onChange={(e) => update("effectiveTo", e.target.value || null)} className={inputClass} />{errorText("effectiveTo")}</div>
        <div className="md:col-span-2"><label className="flex cursor-pointer items-center gap-3"><input type="checkbox" checked={data.active} onChange={(e) => update("active", e.target.checked)} className="h-4 w-4 accent-[#f07837]" /><span className="text-sm font-semibold text-gray-700">Active rule</span></label></div>
      </div>
    </div>
    <footer className="flex flex-wrap justify-end gap-3 border-t bg-gray-50 p-5"><button type="button" onClick={onCancel} disabled={isSaving} className={buttonStyles.cancel}>Cancel</button><button type="button" onClick={() => void handleSave()} disabled={isSaving} className={buttonStyles.save}>{isSaving ? "Saving..." : data.id ? "Update" : "Save"}</button></footer>
  </div>;
};
export default ProductAccessoryRuleWizard;
