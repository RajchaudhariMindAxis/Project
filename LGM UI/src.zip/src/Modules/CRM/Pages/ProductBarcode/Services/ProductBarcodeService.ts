import apiClient from "../../../../../API/apiClient";
import { API_ENDPOINTS } from "../../../../../API/apiConfig";
import type { ProductBarcode, ProductBarcodeListItem } from "./types";

const endpoint = API_ENDPOINTS.ProductBarcode;
export const getProductBarcodes = async (): Promise<ProductBarcodeListItem[]> => (await apiClient.get(endpoint)).data;
export const getProductBarcodeById = async (id: number): Promise<ProductBarcode> => (await apiClient.get(`${endpoint}/${id}`)).data;
export const saveProductBarcode = async (data: ProductBarcode): Promise<void> => {
  const payload = {
    id: data.id || 0,
    barcode: data.barcode.trim(),
    barcodeType: data.barcodeType.trim(),
    productId: data.productId ? Number(data.productId) : null,
    variantId: data.variantId ? Number(data.variantId) : null,
    accessoryId: data.accessoryId ? Number(data.accessoryId) : null,
    isPrimary: data.isPrimary,
    active: data.active,
    isDeleted: data.isDeleted ?? false,
  };
  if (data.id > 0) await apiClient.put(`${endpoint}/${data.id}`, payload);
  else await apiClient.post(endpoint, payload);
};
export const deleteProductBarcode = async (id: number): Promise<void> => { await apiClient.delete(`${endpoint}/${id}`); };
