import React, { useEffect, useState } from "react";
import type { ProductBarcode } from "./Services/types";
import { saveProductBarcode } from "./Services/ProductBarcodeService";
import { toast } from "sonner";
import { buttonStyles } from "../../../../Components/Common/buttonStyles";

interface WizardProps { editData: ProductBarcode | null; onSuccess: () => void; onCancel: () => void; }
const emptyBarcode: ProductBarcode = { id: 0, barcode: "", barcodeType: "", productId: null, variantId: null, accessoryId: null, isPrimary: false, active: true, isDeleted: false };
const ProductBarcodeWizard: React.FC<WizardProps> = ({ editData, onSuccess, onCancel }) => {
  const [data, setData] = useState<ProductBarcode>({ ...emptyBarcode });
  const [isSaving, setIsSaving] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  useEffect(() => { setData(editData ? { ...emptyBarcode, ...editData } : { ...emptyBarcode }); setErrors({}); }, [editData]);
  const update = (field: keyof ProductBarcode, value: string | number | boolean | null) => { setData((old) => ({ ...old, [field]: value })); setErrors((old) => ({ ...old, [field]: "" })); };
  const validate = () => {
    const next: Record<string, string> = {};
    if (!data.barcode.trim()) next.barcode = "Barcode is required.";
    if (data.barcode.length > 100) next.barcode = "Barcode must be 100 characters or fewer.";
    if (!data.barcodeType.trim()) next.barcodeType = "Barcode Type is required.";
    if (data.barcodeType.length > 30) next.barcodeType = "Barcode Type must be 30 characters or fewer.";
    for (const field of ["productId", "variantId", "accessoryId"] as const) {
      const value = data[field];
      if (value !== null && (!Number.isInteger(Number(value)) || Number(value) <= 0)) next[field] = "Enter a positive ID or leave this field blank.";
    }
    setErrors(next); return Object.keys(next).length === 0;
  };
  const handleSave = async () => {
    if (!validate()) { toast.error("Please correct the highlighted fields."); return; }
    setIsSaving(true);
    try { await saveProductBarcode(data); toast.success(data.id > 0 ? "Barcode updated successfully!" : "Barcode created successfully!"); onSuccess(); }
    catch (error: unknown) { toast.error(error instanceof Error ? error.message : "Something went wrong while saving the barcode."); }
    finally { setIsSaving(false); }
  };
  const inputClass = "w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm outline-none transition focus:border-[#f07837] focus:ring-2 focus:ring-[#f07837]/20";
  const labelClass = "mb-1 block text-xs font-bold uppercase tracking-wide text-gray-600";
  const errorText = (key: string) => errors[key] ? <p className="mt-1 text-xs text-red-600">{errors[key]}</p> : null;
  const idInput = (field: "productId" | "variantId" | "accessoryId", label: string) => <div key={field}><label htmlFor={field} className={labelClass}>{label} (optional)</label><input id={field} type="number" min="1" step="1" value={data[field] ?? ""} onChange={(e) => update(field, e.target.value === "" ? null : Number(e.target.value))} className={inputClass} placeholder={`Enter ${label}`} />{errorText(field)}</div>;
  return <div className="mb-8 overflow-hidden rounded-xl border border-gray-200 bg-white shadow-xl">
    <header className="bg-[#f07837] px-6 py-4 text-white"><h2 className="text-lg font-bold uppercase tracking-wide">{data.id ? "Update Product Barcode" : "Add Product Barcode"}</h2><p className="mt-1 text-xs text-white/80">Enter barcode details and its linked item IDs.</p></header>
    <div className="p-5 sm:p-8"><h3 className="mb-5 border-b border-gray-200 pb-3 text-sm font-extrabold uppercase tracking-wide text-[#154068]">Barcode Information</h3>
      <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
        <div><label htmlFor="barcode" className={labelClass}>Barcode *</label><input id="barcode" maxLength={100} value={data.barcode} onChange={(e) => update("barcode", e.target.value)} className={inputClass} placeholder="Enter barcode value" />{errorText("barcode")}</div>
        <div><label htmlFor="barcodeType" className={labelClass}>Barcode Type *</label><input id="barcodeType" maxLength={30} value={data.barcodeType} onChange={(e) => update("barcodeType", e.target.value)} className={inputClass} placeholder="e.g. EAN-13, UPC, QR" />{errorText("barcodeType")}</div>
        {idInput("productId", "Product ID")}
        {idInput("variantId", "Variant ID")}
        {idInput("accessoryId", "Accessory ID")}
        <div className="flex flex-col justify-center gap-4 sm:flex-row sm:items-center sm:justify-start sm:gap-8">
          <label className="flex cursor-pointer items-center gap-3"><input type="checkbox" checked={data.isPrimary} onChange={(e) => update("isPrimary", e.target.checked)} className="h-4 w-4 accent-[#f07837]" /><span className="text-sm font-semibold text-gray-700">Primary barcode</span></label>
          <label className="flex cursor-pointer items-center gap-3"><input type="checkbox" checked={data.active} onChange={(e) => update("active", e.target.checked)} className="h-4 w-4 accent-[#f07837]" /><span className="text-sm font-semibold text-gray-700">Active</span></label>
        </div>
      </div>
    </div>
    <footer className="flex flex-wrap justify-end gap-3 border-t bg-gray-50 p-5"><button type="button" onClick={onCancel} disabled={isSaving} className={buttonStyles.cancel}>Cancel</button><button type="button" onClick={() => void handleSave()} disabled={isSaving} className={buttonStyles.save}>{isSaving ? "Saving..." : data.id ? "Update" : "Save"}</button></footer>
  </div>;
};
export default ProductBarcodeWizard;
