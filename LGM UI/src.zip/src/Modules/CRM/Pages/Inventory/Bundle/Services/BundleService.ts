import apiClient from "../../../../../../API/apiClient";
import { API_ENDPOINTS } from "../../../../../../API/apiConfig";
import type { Bundle, BundleListItem } from "./type";

const endpoint = API_ENDPOINTS.Bundle;

export const getBundles = async (): Promise<BundleListItem[]> => {
  const response = await apiClient.get(endpoint);
  return response.data;
};

export const getBundleById = async (id: number): Promise<Bundle> => {
  const response = await apiClient.get(`${endpoint}/${id}`);
  return response.data;
};

export const saveBundle = async (data: Bundle): Promise<void> => {
  const payload = {
    bundleId: data.bundleId || 0,
    code: data.code.trim(),
    name: data.name.trim(),
    parentProductId: Number(data.parentProductId),
    packagePrice: Number(data.packagePrice),
    taxMode: data.taxMode.trim(),
    effectiveFrom: data.effectiveFrom,
    effectiveTo: data.effectiveTo || null,
    isActive: data.isActive,
    isDeleted: data.isDeleted ?? false,
  };

  if (data.bundleId > 0) {
    await apiClient.put(`${endpoint}/${data.bundleId}`, payload);
  } else {
    await apiClient.post(endpoint, payload);
  }
};

export const deleteBundle = async (id: number): Promise<void> => {
  await apiClient.delete(`${endpoint}/${id}`);
};
