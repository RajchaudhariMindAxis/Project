import apiClient from "../../../../../../API/apiClient";
import { API_ENDPOINTS } from "../../../../../../API/apiConfig";
import type { PaymentMethod, PaymentMethodListItem } from "./types";

const endpoint = API_ENDPOINTS.PaymentMethod;
export const getPaymentMethods = async (): Promise<PaymentMethodListItem[]> => (await apiClient.get(endpoint)).data;
export const getPaymentMethodById = async (id: number): Promise<PaymentMethod> => (await apiClient.get(`${endpoint}/${id}`)).data;
export const savePaymentMethod = async (data: PaymentMethod): Promise<void> => {
  const payload = { paymentMethodId: data.paymentMethodId || 0, code: data.code.trim(), name: data.name.trim(), isActive: data.isActive, isDeleted: data.isDeleted ?? false };
  if (data.paymentMethodId > 0) await apiClient.put(`${endpoint}/${data.paymentMethodId}`, payload);
  else await apiClient.post(endpoint, payload);
};
export const deletePaymentMethod = async (id: number): Promise<void> => { await apiClient.delete(`${endpoint}/${id}`); };
