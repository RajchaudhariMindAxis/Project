import apiClient from "../../../../../../API/apiClient";
import { API_ENDPOINTS } from "../../../../../../API/apiConfig";
import type { Reason, ReasonListItem } from "./types";

const endpoint = API_ENDPOINTS.Reason;
export const getReasons = async (): Promise<ReasonListItem[]> => (await apiClient.get(endpoint)).data;
export const getReasonById = async (id: number): Promise<Reason> => (await apiClient.get(`${endpoint}/${id}`)).data;
export const saveReason = async (data: Reason): Promise<void> => {
  const payload = {
  reasonId: data.reasonId || 0,
  code: data.code.trim(),
  name: data.name.trim(),
  reasonType: data.reasonType.trim(),
  isActive: data.isActive,
  isDeleted: data.isDeleted ?? false,
};
  if (data.reasonId > 0) await apiClient.put(`${endpoint}/${data.reasonId}`, payload);
  else await apiClient.post(endpoint, payload);
};
export const deleteReason = async (id: number): Promise<void> => { await apiClient.delete(`${endpoint}/${id}`); };
