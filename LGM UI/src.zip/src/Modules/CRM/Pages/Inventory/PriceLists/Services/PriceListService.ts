import apiClient from "../../../../../../API/apiClient";
import { API_ENDPOINTS } from "../../../../../../API/apiConfig";
import type { PriceList, PriceListListItem } from "./types";

const endpoint = API_ENDPOINTS.PriceList;
export const getPriceLists = async (): Promise<PriceListListItem[]> => (await apiClient.get(endpoint)).data;
export const getPriceListById = async (id: number): Promise<PriceList> => (await apiClient.get(`${endpoint}/${id}`)).data;
export const savePriceList = async (data: PriceList): Promise<void> => {
  const payload = {
    priceListId: data.priceListId || 0,
    code: data.code.trim(),
    name: data.name.trim(),
    customerChannelType: data.customerChannelType.trim(),
    id: Number(data.id),
    effectiveFrom: data.effectiveFrom,
    effectiveTo: data.effectiveTo || null,
    isActive: data.isActive,
    isDeleted: data.isDeleted ?? false,
  };
  if (data.priceListId > 0) await apiClient.put(`${endpoint}/${data.priceListId}`, payload);
  else await apiClient.post(endpoint, payload);
};
export const deletePriceList = async (id: number): Promise<void> => { await apiClient.delete(`${endpoint}/${id}`); };
