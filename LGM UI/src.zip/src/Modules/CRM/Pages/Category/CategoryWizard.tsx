
import React, { useEffect, useState } from "react";
import { FaLayerGroup } from "react-icons/fa";
import { toast } from "sonner";

import type { Category, CategoryListItem } from "./Services/types";
import {
    getCategories,
    saveCategory,
} from "./Services/CategoryServices";

import { buttonStyles } from "../../../../Components/Common/buttonStyles";

interface CategoryWizardProps {
    editData: Category | null;
    onSuccess: () => void;
    onCancel: () => void;
}

const initialData: Category = {
    categoryId: 0,
    code: "",
    name: "",
    parentCategoryId: null,
    description: "",
    isActive: true,
};

const CategoryWizard: React.FC<CategoryWizardProps> = ({
    editData,
    onSuccess,
    onCancel,
}) => {
    const [data, setData] = useState<Category>({ ...initialData });
    const [categories, setCategories] = useState<CategoryListItem[]>([]);
    const [errors, setErrors] = useState<Record<string, string>>({});
    const [isSaving, setIsSaving] = useState(false);
    const [loadingCategories, setLoadingCategories] = useState(false);

    useEffect(() => {
        setData(
            editData
                ? {
                    ...initialData,
                    ...editData,
                    parentCategoryId: editData.parentCategoryId ?? null,
                    description: editData.description ?? "",
                }
                : { ...initialData }
        );

        setErrors({});
    }, [editData]);

    useEffect(() => {
        const loadCategories = async () => {
            try {
                setLoadingCategories(true);
                const result = await getCategories();
                setCategories(result);
            } catch (error) {
                console.error("Failed to load categories:", error);
                toast.error("Failed to load parent categories.");
            } finally {
                setLoadingCategories(false);
            }
        };

        void loadCategories();
    }, []);

    const handleChange = (
        e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
    ) => {
        const { name, value } = e.target;

        setData((prev) => ({
            ...prev,
            [name]:
                name === "parentCategoryId"
                    ? value === "" ? null : Number(value)
                    : value,
        }));

        setErrors((prev) => ({
            ...prev,
            [name]: "",
        }));
    };

    const handleActiveChange = (
        e: React.ChangeEvent<HTMLInputElement>
    ) => {
        setData((prev) => ({
            ...prev,
            isActive: e.target.checked,
        }));
    };

    const validate = (): boolean => {
        const newErrors: Record<string, string> = {};

        if (!data.code.trim()) {
            newErrors.code = "Category Code is required.";
        }

        if (!data.name.trim()) {
            newErrors.name = "Category Name is required.";
        }

        if (
            data.parentCategoryId !== null &&
            data.parentCategoryId === data.categoryId
        ) {
            newErrors.parentCategoryId =
                "A category cannot be its own parent.";
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (
        e: React.FormEvent<HTMLFormElement>
    ) => {
        e.preventDefault();

        if (!validate()) {
            toast.error("Please correct the required fields.");
            return;
        }

        try {
            setIsSaving(true);

            await saveCategory({
                ...data,
                code: data.code.trim(),
                name: data.name.trim(),
                description: data.description.trim(),
            });

            toast.success(
                data.categoryId > 0
                    ? "Category updated successfully!"
                    : "Category created successfully!"
            );

            onSuccess();
        } catch (error: any) {
            console.error("Category save error:", error);

            toast.error(
                error?.response?.data?.message ||
                error?.message ||
                "Failed to save category."
            );
        } finally {
            setIsSaving(false);
        }
    };

    const inputClass =
        "w-full rounded-md border border-gray-300 px-3 py-2 text-sm outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 disabled:cursor-not-allowed disabled:bg-gray-100";

    const labelClass =
        "mb-1 block text-sm font-semibold text-gray-700";

    return (
        <div className="mb-8 overflow-hidden rounded-xl border border-gray-200 bg-white shadow-xl">
            {/* Header */}
            <div className="flex items-center gap-3 bg-[#f07837] px-6 py-4 text-white">
                <FaLayerGroup className="text-xl" />

                <div>
                    <h2 className="text-lg font-bold uppercase tracking-wide">
                        {data.categoryId > 0
                            ? "Update Category"
                            : "Add Category"}
                    </h2>

                    <p className="mt-1 text-xs text-blue-100">
                        Enter category information below.
                    </p>
                </div>
            </div>

            <form onSubmit={handleSubmit}>
                <div className="bg-white p-6 md:p-8">
                    <div className="mb-6 border-b border-gray-200 pb-3">
                        <h3 className="text-sm font-extrabold uppercase tracking-wide text-[#154068]">
                            Category Information
                        </h3>
                    </div>

                    <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                        {/* Code */}
                        <div>
                            <label htmlFor="code" className={labelClass}>
                                Code <span className="text-red-500">*</span>
                            </label>

                            <input
                                id="code"
                                name="code"
                                type="text"
                                maxLength={50}
                                value={data.code}
                                onChange={handleChange}
                                className={inputClass}
                                placeholder="Enter Category Code"
                            />

                            {errors.code && (
                                <p className="mt-1 text-xs text-red-600">
                                    {errors.code}
                                </p>
                            )}
                        </div>

                        {/* Name */}
                        <div>
                            <label htmlFor="name" className={labelClass}>
                                Name <span className="text-red-500">*</span>
                            </label>

                            <input
                                id="name"
                                name="name"
                                type="text"
                                maxLength={100}
                                value={data.name}
                                onChange={handleChange}
                                className={inputClass}
                                placeholder="Enter Category Name"
                            />

                            {errors.name && (
                                <p className="mt-1 text-xs text-red-600">
                                    {errors.name}
                                </p>
                            )}
                        </div>

                        {/* Parent Category */}
                        <div>
                            <label
                                htmlFor="parentCategoryId"
                                className={labelClass}
                            >
                                Parent Category
                            </label>

                            <select
                                id="parentCategoryId"
                                name="parentCategoryId"
                                value={data.parentCategoryId ?? ""}
                                onChange={handleChange}
                                className={inputClass}
                                disabled={loadingCategories}
                            >
                                <option value="">
                                    {loadingCategories
                                        ? "Loading categories..."
                                        : "No Parent Category"}
                                </option>

                                {categories
                                    .filter(
                                        (category) =>
                                            category.categoryId !== data.categoryId
                                    )
                                    .map((category) => (
                                        <option
                                            key={category.categoryId}
                                            value={category.categoryId}
                                        >
                                            {category.code} - {category.name}
                                        </option>
                                    ))}
                            </select>

                            {errors.parentCategoryId && (
                                <p className="mt-1 text-xs text-red-600">
                                    {errors.parentCategoryId}
                                </p>
                            )}
                        </div>

                        {/* Description */}
                        <div>
                            <label
                                htmlFor="description"
                                className={labelClass}
                            >
                                Description
                            </label>

                            <textarea
                                id="description"
                                name="description"
                                rows={3}
                                maxLength={500}
                                value={data.description}
                                onChange={handleChange}
                                className={inputClass}
                                placeholder="Enter Description"
                            />
                        </div>

                        {/* Active */}
                        <div className="md:col-span-2">
                            <label className="flex cursor-pointer items-center gap-3">
                                <input
                                    type="checkbox"
                                    name="isActive"
                                    checked={data.isActive}
                                    onChange={handleActiveChange}
                                    className="h-4 w-4 accent-blue-700"
                                />

                                <span className="text-sm font-semibold text-gray-700">
                                    Active
                                </span>
                            </label>
                        </div>
                    </div>
                </div>

                {/* Footer */}
                <div className="flex flex-wrap justify-end gap-3 border-t bg-gray-50 p-5">
                    <button
                        type="button"
                        onClick={onCancel}
                        disabled={isSaving}
                        className={buttonStyles.cancel}
                    >
                        Cancel
                    </button>

                    <button
                        type="submit"
                        disabled={isSaving || loadingCategories}
                        className={buttonStyles.save}
                    >
                        {isSaving
                            ? "Saving..."
                            : data.categoryId > 0
                                ? "Update"
                                : "Save"}
                    </button>
                </div>
            </form>
        </div>
    );
};

export default CategoryWizard;
