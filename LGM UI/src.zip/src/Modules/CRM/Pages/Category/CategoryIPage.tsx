
import React, { useEffect, useState } from "react";
import {
    FaEdit,
    FaEye,
    FaTrash,
} from "react-icons/fa";
import { type TableColumn } from "react-data-table-component";
import { toast } from "sonner";

import {
    getCategories,
    getCategoryById,
    deleteCategory,
} from "./Services/CategoryServices";

import type {
    Category,
    CategoryListItem,
} from "./Services/types";

import CategoryWizard from "./CategoryWizard";
import CategoryViewModal from "./CategoryViewModal";

import ListingLayout from "../../../../Components/Common/ListingLayout";
import { actionButtonStyles } from "../../../../Components/Common/buttonStyles";
import { usePermissions } from "../../../../hooks/usePermissions";

const CategoryPage: React.FC = () => {
    const [categories, setCategories] = useState<CategoryListItem[]>([]);
    const [showWizard, setShowWizard] = useState(false);
    const [editData, setEditData] = useState<Category | null>(null);
    const [viewData, setViewData] = useState<Category | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [filterText, setFilterText] = useState("");

    const { hasPermission } = usePermissions();

    const canAdd = hasPermission("Category", "CanAdd");
    const canEdit = hasPermission("Category", "CanEdit");
    const canDelete = hasPermission("Category", "CanDelete");

    const loadCategories = async () => {
        try {
            setIsLoading(true);
            const result = await getCategories();
            setCategories(result);
        } catch (error) {
            console.error("Failed to load categories:", error);
            toast.error("Failed to load categories.");
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        void loadCategories();

        const handleRefresh = () => {
            void loadCategories();
        };

        window.addEventListener("app-refresh", handleRefresh);

        return () => {
            window.removeEventListener("app-refresh", handleRefresh);
        };
    }, []);

    const handleCreateNew = () => {
        setEditData(null);
        setShowWizard(true);
        window.scrollTo({ top: 0, behavior: "smooth" });
    };

    const handleView = async (id: number) => {
        try {
            setIsLoading(true);
            const result = await getCategoryById(id);
            setViewData(result);
        } catch (error) {
            console.error("Failed to load category:", error);
            toast.error("Could not load category details.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleEdit = async (id: number) => {
        try {
            setIsLoading(true);
            const result = await getCategoryById(id);
            setEditData(result);
            setShowWizard(true);
            window.scrollTo({ top: 0, behavior: "smooth" });
        } catch (error) {
            console.error("Failed to load category for editing:", error);
            toast.error("Could not load category for editing.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleDelete = async (id: number) => {
        if (!window.confirm("Are you sure you want to delete this category?")) {
            return;
        }

        try {
            await deleteCategory(id);
            toast.success("Category deleted successfully.");
            await loadCategories();
        } catch (error: any) {
            console.error("Failed to delete category:", error);

            toast.error(
                error?.response?.data?.message ||
                "Could not delete category."
            );
        }
    };

    const handleSuccess = () => {
        setShowWizard(false);
        setEditData(null);
        void loadCategories();
    };

    const columns: TableColumn<CategoryListItem>[] = [
        {
            name: "Sr. No.",
            cell: (_row, index) => (index ?? 0) + 1,
            width: "80px",
        },
        {
            name: "Category ID",
            selector: (row) => row.categoryId,
            sortable: true,
            width: "120px",
        },
        {
            name: "Code",
            selector: (row) => row.code,
            sortable: true,
            grow: 1,
        },
        {
            name: "Name",
            selector: (row) => row.name,
            sortable: true,
            grow: 1.5,
        },
        {
            name: "Parent Category ID",
            selector: (row) => row.parentCategoryId ?? "N/A",
            sortable: true,
            grow: 1,
        },
        {
            name: "Description",
            selector: (row) => row.description || "N/A",
            sortable: true,
            grow: 2,
        },
        {
            name: "Status",
            cell: (row) => (
                <span
                    className={
                        row.isActive
                            ? "rounded bg-green-100 px-2 py-1 text-green-700"
                            : "rounded bg-gray-100 px-2 py-1 text-gray-600"
                    }
                >
                    {row.isActive ? "Active" : "Inactive"}
                </span>
            ),
            width: "110px",
        },
        {
            name: "Actions",
            cell: (row) => (
                <div className="flex justify-center gap-4">
                    <button
                        type="button"
                        onClick={() => void handleView(row.categoryId)}
                        className={`${actionButtonStyles.base} ${actionButtonStyles.view}`}
                        title="View"
                    >
                        <FaEye size={16} />
                    </button>

                    {canEdit && (
                        <button
                            type="button"
                            onClick={() => void handleEdit(row.categoryId)}
                            className={`${actionButtonStyles.base} ${actionButtonStyles.edit}`}
                            title="Edit"
                        >
                            <FaEdit size={16} />
                        </button>
                    )}

                    {canDelete && (
                        <button
                            type="button"
                            onClick={() => void handleDelete(row.categoryId)}
                            className={`${actionButtonStyles.base} ${actionButtonStyles.delete}`}
                            title="Delete"
                        >
                            <FaTrash size={16} />
                        </button>
                    )}
                </div>
            ),
            width: "140px",
        },
    ];

    const filteredItems = categories.filter((item) =>
        JSON.stringify(item).toLowerCase().includes(filterText.toLowerCase())
    );

    return (
        <div className="min-h-screen space-y-6 bg-[#f5f6fa] p-4">
            {/* Add / Edit */}
            {showWizard && (
                <CategoryWizard
                    editData={editData}
                    onSuccess={handleSuccess}
                    onCancel={() => {
                        setShowWizard(false);
                        setEditData(null);
                    }}
                />
            )}

            {/* View */}
            {viewData && (
                <CategoryViewModal
                    category={viewData}
                    onClose={() => setViewData(null)}
                />
            )}

            {/* Listing */}
            <ListingLayout
                title="Listing of Categories"
                columns={columns}
                data={filteredItems}
                isLoading={isLoading}
                filterText={filterText}
                onFilterChange={setFilterText}
                onCreate={canAdd ? handleCreateNew : undefined}
            />
        </div>
    );
};

export default CategoryPage;
