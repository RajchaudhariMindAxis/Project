
export interface Category {
    categoryId: number;
    code: string;
    name: string;
    parentCategoryId: number | null;
    description: string;
    isActive: boolean;
}

export interface CategoryListItem {
    categoryId: number;
    code: string;
    name: string;
    parentCategoryId: number | null;
    description: string;
    isActive: boolean;
}
