
import apiClient from "../../../../../API/apiClient";
import { API_ENDPOINTS } from "../../../../../API/apiConfig";
import type { Category, CategoryListItem } from "./types";

const normalizeCategory = (item: any): CategoryListItem => ({
    categoryId: item.categoryId ?? item.CategoryId ?? 0,
    code: item.code ?? item.Code ?? "",
    name: item.name ?? item.Name ?? "",
    parentCategoryId:
        item.parentCategoryId ?? item.ParentCategoryId ?? null,
    description: item.description ?? item.Description ?? "",
    isActive: item.isActive ?? item.IsActive ?? true,
});

// Get all categories
export const getCategories = async (): Promise<CategoryListItem[]> => {
    const res = await apiClient.get(API_ENDPOINTS.Category);

    return (res.data as any[]).map(normalizeCategory);
};

// Get category by ID
export const getCategoryById = async (
    id: number
): Promise<Category> => {
    const res = await apiClient.get(`${API_ENDPOINTS.Category}/${id}`);
    const item = normalizeCategory(res.data);

    return {
        ...item,
        parentCategoryId: item.parentCategoryId ?? null,
    };
};

// Create or update category
export const saveCategory = async (
    data: Category
): Promise<void> => {
    const payload = {
        categoryId: data.categoryId || 0,
        code: data.code.trim(),
        name: data.name.trim(),
        parentCategoryId: data.parentCategoryId || null,
        description: data.description.trim() || null,
        isActive: data.isActive,
    };

    if (data.categoryId > 0) {
        await apiClient.put(
            `${API_ENDPOINTS.Category}/${data.categoryId}`,
            payload
        );
    } else {
        await apiClient.post(API_ENDPOINTS.Category, payload);
    }
};

// Delete category
export const deleteCategory = async (id: number): Promise<void> => {
    await apiClient.delete(`${API_ENDPOINTS.Category}/${id}`);
};
